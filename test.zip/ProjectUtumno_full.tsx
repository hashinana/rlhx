<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="ProjectUtumno_full" tilewidth="32" tileheight="32" tilecount="6080" columns="64">
 <image source="../V7/V7 rc3/ProjectUtumno_full.png" width="2048" height="3040"/>
</tileset>
