<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="basics" tilewidth="32" tileheight="32" tilecount="1995" columns="15">
 <image source="cija_32x32_expansion for Pipoya_CC0.png" width="480" height="4256"/>
</tileset>
