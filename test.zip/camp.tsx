<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="camp" tilewidth="32" tileheight="32" tilecount="140" columns="14">
 <image source="cccamp1.jpg" width="474" height="320"/>
</tileset>
