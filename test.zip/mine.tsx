<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="mine" tilewidth="32" tileheight="32" tilecount="11625" columns="125">
 <image source="IMG_20190627_024211.jpg" width="4000" height="3000"/>
</tileset>
