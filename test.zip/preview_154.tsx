<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="preview_154" tilewidth="32" tileheight="32" tilecount="483" columns="21">
 <image source="preview_154.png" width="698" height="763"/>
</tileset>
