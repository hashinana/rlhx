<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="rZ5Z6I" tilewidth="32" tileheight="32" tilecount="768" columns="32">
 <image source="rZ5Z6I.png" width="1024" height="768"/>
</tileset>
