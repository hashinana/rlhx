<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="rc3-mullana-overlay" tilewidth="32" tileheight="32" tilecount="512" columns="16">
 <image source="rc3-mullana-overlay.png" width="512" height="1024"/>
</tileset>
