<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="test3" tilewidth="32" tileheight="32" tilecount="768" columns="32">
 <image source="test3.jpg" width="1024" height="768"/>
</tileset>
